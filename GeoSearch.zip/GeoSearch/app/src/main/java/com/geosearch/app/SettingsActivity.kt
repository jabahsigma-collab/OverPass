package com.geosearch.app

import android.content.Context
import android.os.Bundle
import android.widget.ImageButton
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<ImageButton>(R.id.backButton).setOnClickListener { finish() }

        val group = findViewById<RadioGroup>(R.id.languageGroup)
        val english = findViewById<RadioButton>(R.id.radioEnglish)
        val russian = findViewById<RadioButton>(R.id.radioRussian)

        if (LocaleHelper.getLang(this) == "ru") russian.isChecked = true else english.isChecked = true

        group.setOnCheckedChangeListener { _, checkedId ->
            val lang = if (checkedId == R.id.radioRussian) "ru" else "en"
            if (lang != LocaleHelper.getLang(this)) {
                LocaleHelper.setLang(this, lang)
                recreate()
            }
        }
    }
}
