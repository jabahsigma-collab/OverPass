package com.geosearch.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class Place(
    val key: String,
    val name: String,
    val lat: Double,
    val lon: Double,
    val description: String
)

/** Клиент Overpass API: ищет объекты по названию (name, name:ru, name:en ...) в заданном прямоугольнике. */
class OverpassClient {

    private val endpoints = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter"
    )

    suspend fun search(
        text: String,
        south: Double,
        west: Double,
        north: Double,
        east: Double
    ): List<Place> = withContext(Dispatchers.IO) {
        val ql = buildQuery(text, south, west, north, east)
        var last: IOException? = null
        for (endpoint in endpoints) {
            try {
                return@withContext parse(post(endpoint, ql))
            } catch (e: IOException) {
                last = e
            } catch (e: JSONException) {
                last = IOException("Bad response", e)
            }
        }
        throw last ?: IOException("No response")
    }

    private fun buildQuery(text: String, s: Double, w: Double, n: Double, e: Double): String {
        val rx = escape(text)
        val bbox = String.format(Locale.US, "(%.6f,%.6f,%.6f,%.6f)", s, w, n, e)
        val filter = "[~\"^name(:.*)?\$\"~\"$rx\",i]"
        return "[out:json][timeout:25];(node$filter$bbox;way$filter$bbox;relation$filter$bbox;);out center 60;"
    }

    /** Экранирует текст пользователя для regexp внутри строки Overpass QL. */
    private fun escape(text: String): String {
        val special = "^\$.*+?()[]{}|"
        val sb = StringBuilder()
        for (ch in text.replace("\\", "")) {
            when {
                ch == '"' -> sb.append("\\\"")
                special.indexOf(ch) >= 0 -> sb.append("\\\\").append(ch)
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun post(endpoint: String, ql: String): String {
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 40000
            conn.doOutput = true
            conn.setRequestProperty("User-Agent", "GeoSearch-Android/1.0")
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            conn.outputStream.use {
                it.write(("data=" + URLEncoder.encode(ql, "UTF-8")).toByteArray())
            }
            val code = conn.responseCode
            if (code != 200) throw IOException("HTTP $code")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(json: String): List<Place> {
        val elements = JSONObject(json).optJSONArray("elements") ?: return emptyList()
        val result = ArrayList<Place>()
        val kindKeys = listOf(
            "amenity", "shop", "tourism", "historic", "place", "natural",
            "leisure", "railway", "highway", "waterway", "building"
        )
        for (i in 0 until elements.length()) {
            val el = elements.getJSONObject(i)
            val tags = el.optJSONObject("tags") ?: continue
            val type = el.optString("type")
            val id = el.optLong("id")

            var name = tags.optString("name")
            if (name.isEmpty()) {
                val it = tags.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    if (k.startsWith("name:")) {
                        name = tags.optString(k)
                        break
                    }
                }
            }
            if (name.isEmpty()) continue

            val lat: Double
            val lon: Double
            if (type == "node") {
                if (!el.has("lat") || !el.has("lon")) continue
                lat = el.getDouble("lat")
                lon = el.getDouble("lon")
            } else {
                val center = el.optJSONObject("center") ?: continue
                lat = center.getDouble("lat")
                lon = center.getDouble("lon")
            }

            var kind = type
            for (k in kindKeys) {
                if (tags.has(k)) {
                    kind = k + "=" + tags.optString(k)
                    break
                }
            }
            result.add(Place("$type/$id", name, lat, lon, kind))
        }
        return result
    }
}
