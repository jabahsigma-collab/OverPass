package com.geosearch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

enum class CellState { PENDING, SEARCHING, FOUND, EMPTY, ERROR }

/** Квадрат-лог: сетка ячеек, которые закрашиваются по мере поиска в соответствующих местах карты. */
class SearchGridView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var n = 5
    private var states = Array(n * n) { CellState.PENDING }
    private var counts = IntArray(n * n)

    private val d = resources.displayMetrics.density
    private val rect = RectF()

    private val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#A5D6A7")
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
    }
    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    fun reset(size: Int) {
        n = size
        states = Array(n * n) { CellState.PENDING }
        counts = IntArray(n * n)
        invalidate()
    }

    fun setCell(index: Int, state: CellState, count: Int = 0) {
        if (index in states.indices) {
            states[index] = state
            counts[index] = count
            invalidate()
        }
    }

    private fun colorOf(state: CellState): Int = when (state) {
        CellState.PENDING -> Color.parseColor("#E0E0E0")
        CellState.SEARCHING -> Color.parseColor("#FFC107")
        CellState.FOUND -> Color.parseColor("#43A047")
        CellState.EMPTY -> Color.parseColor("#C8E6C9")
        CellState.ERROR -> Color.parseColor("#E53935")
    }

    override fun onDraw(canvas: Canvas) {
        val side = min(width, height).toFloat()
        rect.set(0f, 0f, side, side)
        canvas.drawRoundRect(rect, 12 * d, 12 * d, cardPaint)
        rect.set(borderPaint.strokeWidth / 2, borderPaint.strokeWidth / 2,
            side - borderPaint.strokeWidth / 2, side - borderPaint.strokeWidth / 2)
        canvas.drawRoundRect(rect, 12 * d, 12 * d, borderPaint)

        val pad = 8 * d
        val gap = 3 * d
        val cs = (side - 2 * pad - gap * (n - 1)) / n
        textPaint.textSize = cs * 0.45f

        for (r in 0 until n) {
            for (c in 0 until n) {
                val i = r * n + c
                val left = pad + c * (cs + gap)
                val top = pad + r * (cs + gap)
                rect.set(left, top, left + cs, top + cs)
                cellPaint.color = colorOf(states[i])
                canvas.drawRoundRect(rect, 4 * d, 4 * d, cellPaint)
                if (states[i] == CellState.FOUND && counts[i] > 0) {
                    val y = rect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2
                    canvas.drawText(counts[i].toString(), rect.centerX(), y, textPaint)
                }
            }
        }
    }
}
