package com.geosearch.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Cell(val south: Double, val west: Double, val north: Double, val east: Double)

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var queryInput: EditText
    private lateinit var runButton: MaterialButton
    private lateinit var statusText: TextView
    private lateinit var gridView: SearchGridView
    private lateinit var logText: TextView
    private lateinit var logScroll: ScrollView

    private val gridSize = 5
    private val cells = ArrayList<Cell>()
    private val cellPolygons = ArrayList<Polygon>()
    private val resultMarkers = ArrayList<Marker>()
    private val client = OverpassClient()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    private var searchJob: Job? = null
    private var langAtCreate = "en"

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        langAtCreate = LocaleHelper.getLang(this)
        initOsmdroid()
        setContentView(R.layout.activity_main)

        map = findViewById(R.id.map)
        queryInput = findViewById(R.id.queryInput)
        runButton = findViewById(R.id.runButton)
        statusText = findViewById(R.id.statusText)
        gridView = findViewById(R.id.gridView)
        logText = findViewById(R.id.logText)
        logScroll = findViewById(R.id.logScroll)

        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.minZoomLevel = 3.0
        map.controller.setZoom(5.0)
        map.controller.setCenter(GeoPoint(48.0, 20.0))

        gridView.reset(gridSize)
        statusText.text = getString(R.string.status_idle)
        log(getString(R.string.log_ready))

        runButton.setOnClickListener {
            if (searchJob?.isActive == true) stopSearch() else startSearch()
        }
        queryInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                if (searchJob?.isActive != true) startSearch()
                true
            } else false
        }
        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun initOsmdroid() {
        val conf = Configuration.getInstance()
        conf.userAgentValue = packageName
        val base = File(filesDir, "osmdroid").apply { mkdirs() }
        val tiles = File(cacheDir, "osmdroid_tiles").apply { mkdirs() }
        conf.osmdroidBasePath = base
        conf.osmdroidTileCache = tiles
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        if (LocaleHelper.getLang(this) != langAtCreate) recreate()
    }

    override fun onPause() {
        map.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        searchJob?.cancel()
        map.onDetach()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- поиск

    private fun startSearch() {
        val query = queryInput.text.toString().trim()
        if (query.isEmpty()) {
            Toast.makeText(this, R.string.empty_query, Toast.LENGTH_SHORT).show()
            return
        }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(queryInput.windowToken, 0)

        val bb = map.boundingBox
        val north = bb.latNorth.coerceIn(-85.0, 85.0)
        val south = bb.latSouth.coerceIn(-85.0, 85.0)
        val east = bb.lonEast.coerceIn(-180.0, 180.0)
        val west = bb.lonWest.coerceIn(-180.0, 180.0)

        if (north - south > 6.0 || east - west > 6.0) {
            Toast.makeText(this, R.string.zoom_in, Toast.LENGTH_LONG).show()
            log(getString(R.string.log_zoom_in))
            return
        }

        prepareCells(south, west, north, east)

        searchJob = lifecycleScope.launch {
            setRunning(true)
            log(getString(R.string.log_start, query, "${fmt(south)}, ${fmt(west)} … ${fmt(north)}, ${fmt(east)}"))
            val seen = HashSet<String>()
            val points = ArrayList<GeoPoint>()
            var total = 0
            var errors = 0
            try {
                for (i in cells.indices) {
                    val cell = cells[i]
                    setCell(i, CellState.SEARCHING)
                    statusText.text = getString(R.string.status_searching, i + 1, cells.size)
                    val where = "${fmt((cell.north + cell.south) / 2)}, ${fmt((cell.west + cell.east) / 2)}"
                    try {
                        val places = client.search(query, cell.south, cell.west, cell.north, cell.east)
                        val fresh = places.filter { seen.add(it.key) }
                        fresh.forEach {
                            addMarker(it)
                            points.add(GeoPoint(it.lat, it.lon))
                        }
                        total += fresh.size
                        setCell(i, if (fresh.isEmpty()) CellState.EMPTY else CellState.FOUND, fresh.size)
                        log(getString(R.string.log_cell, i + 1, cells.size, where, fresh.size))
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        errors++
                        setCell(i, CellState.ERROR)
                        log(getString(R.string.log_cell_error, i + 1, cells.size, e.message ?: e.javaClass.simpleName))
                    }
                    delay(500)
                }
                statusText.text = getString(R.string.status_done, total)
                log(getString(R.string.log_done, total, errors))
                zoomToResults(points)
            } catch (e: CancellationException) {
                statusText.text = getString(R.string.status_stopped)
                log(getString(R.string.log_stopped))
                throw e
            } finally {
                setRunning(false)
            }
        }
    }

    private fun stopSearch() {
        searchJob?.cancel()
    }

    private fun setRunning(running: Boolean) {
        runButton.text = getString(if (running) R.string.stop else R.string.run)
        runButton.setIconResource(if (running) R.drawable.ic_stop else R.drawable.ic_play)
    }

    // ---------------------------------------------------------------- карта и сетка

    private fun prepareCells(south: Double, west: Double, north: Double, east: Double) {
        map.overlays.removeAll(cellPolygons.toSet())
        map.overlays.removeAll(resultMarkers.toSet())
        cells.clear()
        cellPolygons.clear()
        resultMarkers.clear()
        gridView.reset(gridSize)

        val dLat = (north - south) / gridSize
        val dLon = (east - west) / gridSize
        for (r in 0 until gridSize) {
            for (c in 0 until gridSize) {
                val cellNorth = north - dLat * r
                val cellSouth = north - dLat * (r + 1)
                val cellWest = west + dLon * c
                val cellEast = west + dLon * (c + 1)
                val cell = Cell(cellSouth, cellWest, cellNorth, cellEast)
                cells.add(cell)
                val polygon = makePolygon(cell)
                cellPolygons.add(polygon)
                map.overlays.add(polygon)
            }
        }
        map.invalidate()
    }

    private fun makePolygon(c: Cell): Polygon {
        val polygon = Polygon()
        polygon.points = listOf(
            GeoPoint(c.north, c.west),
            GeoPoint(c.north, c.east),
            GeoPoint(c.south, c.east),
            GeoPoint(c.south, c.west),
            GeoPoint(c.north, c.west)
        )
        polygon.outlinePaint.color = Color.argb(150, 46, 125, 50)
        polygon.outlinePaint.strokeWidth = 2f
        polygon.fillPaint.color = stateColor(CellState.PENDING)
        polygon.setOnClickListener { _, _, _ -> false }
        return polygon
    }

    private fun stateColor(state: CellState): Int = when (state) {
        CellState.PENDING -> Color.argb(25, 120, 144, 156)
        CellState.SEARCHING -> Color.argb(120, 255, 193, 7)
        CellState.FOUND -> Color.argb(90, 67, 160, 71)
        CellState.EMPTY -> Color.argb(40, 129, 199, 132)
        CellState.ERROR -> Color.argb(100, 229, 57, 53)
    }

    private fun setCell(index: Int, state: CellState, count: Int = 0) {
        gridView.setCell(index, state, count)
        cellPolygons.getOrNull(index)?.let { it.fillPaint.color = stateColor(state) }
        map.invalidate()
    }

    private fun addMarker(place: Place) {
        val marker = Marker(map)
        marker.position = GeoPoint(place.lat, place.lon)
        marker.title = place.name
        marker.snippet = place.description
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        map.overlays.add(marker)
        resultMarkers.add(marker)
    }

    private fun zoomToResults(points: List<GeoPoint>) {
        when {
            points.isEmpty() -> Unit
            points.size == 1 -> {
                map.controller.setZoom(15.0)
                map.controller.animateTo(points[0])
            }
            else -> {
                val box = BoundingBox.fromGeoPoints(points)
                if (box.latitudeSpan > 0.0 || box.longitudeSpan > 0.0) {
                    map.zoomToBoundingBox(box, true, 120)
                }
            }
        }
    }

    // ---------------------------------------------------------------- лог

    private fun log(message: String) {
        logText.append("${timeFormat.format(Date())}  $message\n")
        logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun fmt(value: Double): String = String.format(Locale.US, "%.3f", value)
}
